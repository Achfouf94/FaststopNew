import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/route_model.dart';
import '../models/stop_model.dart';
import '../utils/app_theme.dart';

class RouteCard extends StatelessWidget {
  final DeliveryRoute route;
  final VoidCallback onTap;
  const RouteCard({super.key, required this.route, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDraft = route.status == RouteStatus.draft;
    final isActive = route.status == RouteStatus.active;
    final color = isActive ? AppTheme.accent : isDraft ? AppTheme.textMuted : AppTheme.primary;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.surfaceDark, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isActive ? AppTheme.accent.withOpacity(0.4) : AppTheme.borderDark),
          boxShadow: isActive ? [BoxShadow(color: AppTheme.accent.withOpacity(0.08), blurRadius: 12)] : null),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(route.name,
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 15, fontWeight: FontWeight.w700),
              overflow: TextOverflow.ellipsis)),
            _StatusBadge(route.status),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Icon(Icons.calendar_today_rounded, size: 13, color: AppTheme.textFaint),
            const SizedBox(width: 4),
            Text(DateFormat('dd MMM yyyy', 'fr_FR').format(route.date),
              style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
            const SizedBox(width: 16),
            Icon(Icons.location_on_rounded, size: 13, color: AppTheme.textFaint),
            const SizedBox(width: 4),
            Text('${route.stops.length} stops',
              style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
          ]),
          if (route.status != RouteStatus.draft) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: route.completionRate / 100,
                backgroundColor: AppTheme.borderDark,
                valueColor: AlwaysStoppedAnimation<Color>(color),
                minHeight: 4)),
            const SizedBox(height: 6),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${route.deliveredCount} livres / ${route.stops.length}',
                style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
              if (route.totalDistanceKm > 0)
                Text('${route.totalDistanceKm.toStringAsFixed(1)} km',
                  style: const TextStyle(color: AppTheme.textFaint, fontSize: 11)),
            ]),
          ],
        ]),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final RouteStatus s;
  const _StatusBadge(this.s);
  @override
  Widget build(BuildContext context) {
    Color c; String t;
    switch (s) {
      case RouteStatus.active: c = AppTheme.accent; t = 'En cours'; break;
      case RouteStatus.completed: c = AppTheme.primary; t = 'Termine'; break;
      case RouteStatus.paused: c = AppTheme.warning; t = 'Pause'; break;
      default: c = AppTheme.textFaint; t = 'Brouillon';
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: c.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
      child: Text(t, style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w700)));
  }
}
