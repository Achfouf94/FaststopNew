import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../models/stop_model.dart';
import '../utils/app_theme.dart';
import '../services/geo_service.dart';

class StopTile extends StatelessWidget {
  final Stop stop;
  final int index;
  final bool isReadOnly;
  final Function(StopStatus, String?)? onStatusChange;
  final VoidCallback? onNavigate;

  const StopTile({super.key, required this.stop, required this.index,
    this.isReadOnly = false, this.onStatusChange, this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final isPending = stop.status == StopStatus.pending;
    final isDelivered = stop.status == StopStatus.delivered;

    Widget tile = Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderColor())),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(children: [
          // Index / Status icon
          Container(
            width: 32, height: 32,
            decoration: BoxDecoration(
              color: _iconBg(), borderRadius: BorderRadius.circular(10)),
            child: isReadOnly || isPending
                ? Center(child: Text('$index',
                    style: TextStyle(color: _iconColor(), fontSize: 13, fontWeight: FontWeight.w700)))
                : Icon(_statusIcon(), color: _iconColor(), size: 16)),
          const SizedBox(width: 12),
          // Content
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(stop.address,
              style: TextStyle(
                color: isDelivered ? AppTheme.textMuted : AppTheme.textPrimary,
                fontSize: 14, fontWeight: FontWeight.w600,
                decoration: isDelivered ? TextDecoration.lineThrough : null),
              maxLines: 2, overflow: TextOverflow.ellipsis),
            if (stop.clientName != null) ...[
              const SizedBox(height: 2),
              Text(stop.clientName!,
                style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
            ],
            if (stop.notes != null && stop.notes!.isNotEmpty) ...[
              const SizedBox(height: 2),
              Text(stop.notes!, style: const TextStyle(color: AppTheme.textFaint, fontSize: 11),
                maxLines: 1, overflow: TextOverflow.ellipsis),
            ],
          ])),
          // Actions
          if (!isReadOnly && onNavigate != null) ...[
            const SizedBox(width: 8),
            GestureDetector(
              onTap: onNavigate,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.navigation_rounded, color: AppTheme.accent, size: 18))),
          ],
          if (stop.clientPhone != null && !isReadOnly) ...[
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => GeoService.call(stop.clientPhone!),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.phone_rounded, color: AppTheme.primary, size: 18))),
          ],
        ]),
      ),
    );

    if (isReadOnly || onStatusChange == null) return tile;

    return Slidable(
      key: ValueKey(stop.id),
      startActionPane: ActionPane(
        motion: const DrawerMotion(),
        extentRatio: 0.28,
        children: [
          CustomSlidableAction(
            onPressed: (_) {
              HapticFeedback.mediumImpact();
              onStatusChange!(StopStatus.delivered, null);
            },
            backgroundColor: AppTheme.primary,
            borderRadius: BorderRadius.circular(14),
            child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.check_rounded, color: Colors.white, size: 24),
              SizedBox(height: 4),
              Text('Livre', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
            ]),
          ),
        ],
      ),
      endActionPane: ActionPane(
        motion: const DrawerMotion(),
        extentRatio: 0.28,
        children: [
          CustomSlidableAction(
            onPressed: (_) => _showFailureDialog(context),
            backgroundColor: AppTheme.error,
            borderRadius: BorderRadius.circular(14),
            child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.close_rounded, color: Colors.white, size: 24),
              SizedBox(height: 4),
              Text('Echec', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
            ]),
          ),
        ],
      ),
      child: tile,
    );
  }

  void _showFailureDialog(BuildContext context) {
    HapticFeedback.mediumImpact();
    final reasons = ['Absent', 'Adresse introuvable', 'Colis refuse', 'Boite aux lettres pleine', 'Autre'];
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surfaceDark,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Raison de l\'echec',
            style: TextStyle(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          ...reasons.map((r) => ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.radio_button_unchecked, color: AppTheme.textMuted, size: 18),
            title: Text(r, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14)),
            onTap: () {
              Navigator.pop(context);
              onStatusChange!(r == 'Absent' ? StopStatus.absent : StopStatus.failed, r);
            },
          )),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Color _borderColor() {
    switch (stop.status) {
      case StopStatus.delivered: return AppTheme.primary.withOpacity(0.3);
      case StopStatus.failed: return AppTheme.error.withOpacity(0.3);
      case StopStatus.absent: return AppTheme.warning.withOpacity(0.3);
      default: return AppTheme.borderDark;
    }
  }

  Color _iconBg() {
    switch (stop.status) {
      case StopStatus.delivered: return AppTheme.primary.withOpacity(0.15);
      case StopStatus.failed: return AppTheme.error.withOpacity(0.15);
      case StopStatus.absent: return AppTheme.warning.withOpacity(0.15);
      default: return AppTheme.surface2;
    }
  }

  Color _iconColor() {
    switch (stop.status) {
      case StopStatus.delivered: return AppTheme.primary;
      case StopStatus.failed: return AppTheme.error;
      case StopStatus.absent: return AppTheme.warning;
      default: return AppTheme.textMuted;
    }
  }

  IconData _statusIcon() {
    switch (stop.status) {
      case StopStatus.delivered: return Icons.check_circle_rounded;
      case StopStatus.failed: return Icons.cancel_rounded;
      case StopStatus.absent: return Icons.person_off_rounded;
      default: return Icons.radio_button_unchecked_rounded;
    }
  }
}
