import 'package:uuid/uuid.dart';

enum StopStatus { pending, delivered, failed, absent, postponed }
enum StopPriority { normal, high, urgent }

class Stop {
  final String id;
  String address;
  String? clientName;
  String? clientPhone;
  String? notes;
  StopStatus status;
  StopPriority priority;
  int order;
  double? latitude;
  double? longitude;
  DateTime? completedAt;
  String? failureReason;
  List<String> photos;
  String? packageRef;
  bool isVisited;
  double? distanceFromPrev;

  Stop({
    String? id, required this.address, this.clientName, this.clientPhone, this.notes,
    this.status = StopStatus.pending, this.priority = StopPriority.normal,
    required this.order, this.latitude, this.longitude, this.completedAt,
    this.failureReason, List<String>? photos, this.packageRef,
    this.isVisited = false, this.distanceFromPrev,
  }) : id = id ?? const Uuid().v4(), photos = photos ?? [];

  Stop copyWith({
    String? address, String? clientName, String? clientPhone, String? notes,
    StopStatus? status, StopPriority? priority, int? order,
    double? latitude, double? longitude, DateTime? completedAt,
    String? failureReason, List<String>? photos, String? packageRef,
    bool? isVisited, double? distanceFromPrev,
  }) => Stop(
    id: id, address: address ?? this.address, clientName: clientName ?? this.clientName,
    clientPhone: clientPhone ?? this.clientPhone, notes: notes ?? this.notes,
    status: status ?? this.status, priority: priority ?? this.priority,
    order: order ?? this.order, latitude: latitude ?? this.latitude,
    longitude: longitude ?? this.longitude, completedAt: completedAt ?? this.completedAt,
    failureReason: failureReason ?? this.failureReason, photos: photos ?? this.photos,
    packageRef: packageRef ?? this.packageRef, isVisited: isVisited ?? this.isVisited,
    distanceFromPrev: distanceFromPrev ?? this.distanceFromPrev,
  );

  Map<String, dynamic> toMap() => {
    'id': id, 'address': address, 'clientName': clientName, 'clientPhone': clientPhone,
    'notes': notes, 'status': status.index, 'priority': priority.index, 'order': order,
    'latitude': latitude, 'longitude': longitude,
    'completedAt': completedAt?.millisecondsSinceEpoch,
    'failureReason': failureReason, 'photos': photos.join('|'),
    'packageRef': packageRef, 'isVisited': isVisited ? 1 : 0, 'distanceFromPrev': distanceFromPrev,
  };

  factory Stop.fromMap(Map<String, dynamic> m) => Stop(
    id: m['id'], address: m['address'], clientName: m['clientName'],
    clientPhone: m['clientPhone'], notes: m['notes'],
    status: StopStatus.values[m['status'] ?? 0],
    priority: StopPriority.values[m['priority'] ?? 0], order: m['order'],
    latitude: m['latitude'], longitude: m['longitude'],
    completedAt: m['completedAt'] != null ? DateTime.fromMillisecondsSinceEpoch(m['completedAt']) : null,
    failureReason: m['failureReason'],
    photos: m['photos'] != null && m['photos'].toString().isNotEmpty ? m['photos'].toString().split('|') : [],
    packageRef: m['packageRef'], isVisited: m['isVisited'] == 1,
    distanceFromPrev: m['distanceFromPrev'],
  );

  bool get isCompleted => status == StopStatus.delivered;
  bool get hasFailed => status == StopStatus.failed || status == StopStatus.absent;
}
