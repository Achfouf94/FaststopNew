import 'package:uuid/uuid.dart';
import 'stop_model.dart';

enum RouteStatus { draft, active, completed, paused }

class DeliveryRoute {
  final String id;
  String name;
  DateTime date;
  RouteStatus status;
  List<Stop> stops;
  String? startAddress;
  DateTime? startedAt;
  DateTime? completedAt;
  double totalDistanceKm;
  int totalStops;

  DeliveryRoute({
    String? id, required this.name, required this.date,
    this.status = RouteStatus.draft, List<Stop>? stops, this.startAddress,
    this.startedAt, this.completedAt, this.totalDistanceKm = 0.0, this.totalStops = 0,
  }) : id = id ?? const Uuid().v4(), stops = stops ?? [];

  int get deliveredCount => stops.where((s) => s.status == StopStatus.delivered).length;
  int get failedCount => stops.where((s) => s.hasFailed).length;
  int get pendingCount => stops.where((s) => s.status == StopStatus.pending).length;
  double get completionRate => stops.isEmpty ? 0 : (deliveredCount / stops.length) * 100;

  Map<String, dynamic> toMap() => {
    'id': id, 'name': name, 'date': date.millisecondsSinceEpoch, 'status': status.index,
    'startAddress': startAddress, 'startedAt': startedAt?.millisecondsSinceEpoch,
    'completedAt': completedAt?.millisecondsSinceEpoch,
    'totalDistanceKm': totalDistanceKm, 'totalStops': totalStops,
  };

  factory DeliveryRoute.fromMap(Map<String, dynamic> m, {List<Stop>? stops}) => DeliveryRoute(
    id: m['id'], name: m['name'],
    date: DateTime.fromMillisecondsSinceEpoch(m['date']),
    status: RouteStatus.values[m['status'] ?? 0],
    stops: stops ?? [], startAddress: m['startAddress'],
    startedAt: m['startedAt'] != null ? DateTime.fromMillisecondsSinceEpoch(m['startedAt']) : null,
    completedAt: m['completedAt'] != null ? DateTime.fromMillisecondsSinceEpoch(m['completedAt']) : null,
    totalDistanceKm: m['totalDistanceKm'] ?? 0.0, totalStops: m['totalStops'] ?? 0,
  );
}
