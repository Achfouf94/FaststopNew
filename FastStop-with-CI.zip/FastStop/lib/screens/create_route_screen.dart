import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/stop_model.dart';
import '../services/route_provider.dart';
import '../utils/app_theme.dart';
import 'route_detail_screen.dart';

class CreateRouteScreen extends StatefulWidget {
  const CreateRouteScreen({super.key});
  @override State<CreateRouteScreen> createState() => _CreateRouteScreenState();
}

class _CreateRouteScreenState extends State<CreateRouteScreen> {
  final _nameCtrl = TextEditingController(text: 'Route du ${_today()}');
  final _stops = <_StopInput>[];
  bool _saving = false;

  static String _today() {
    final n = DateTime.now();
    return '${n.day.toString().padLeft(2,'0')}/${n.month.toString().padLeft(2,'0')}/${n.year}';
  }

  @override void dispose() { _nameCtrl.dispose(); super.dispose(); }

  void _addStop() => setState(() => _stops.add(_StopInput()));

  Future<void> _save() async {
    final validStops = _stops.where((s) => s.address.trim().isNotEmpty).toList();
    if (validStops.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ajoute au moins un stop'), backgroundColor: AppTheme.error));
      return;
    }
    setState(() => _saving = true);
    final provider = context.read<RouteProvider>();
    final route = await provider.createRoute(_nameCtrl.text.trim().isEmpty ? 'Route' : _nameCtrl.text.trim());
    for (int i = 0; i < validStops.length; i++) {
      final s = validStops[i];
      await provider.addStop(route, Stop(
        address: s.address.trim(), clientName: s.client.trim().isEmpty ? null : s.client.trim(),
        clientPhone: s.phone.trim().isEmpty ? null : s.phone.trim(),
        notes: s.notes.trim().isEmpty ? null : s.notes.trim(), order: i));
    }
    // Auto-optimize si > 3 stops avec adresses
    if (validStops.length > 3) {
      await provider.optimizeRoute(route);
    }
    if (mounted) {
      Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => RouteDetailScreen(route: route)));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    appBar: AppBar(
      backgroundColor: AppTheme.surfaceDark,
      title: const Text('Nouvelle route', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w700)),
      actions: [
        _saving
            ? const Padding(padding: EdgeInsets.all(16),
                child: SizedBox(width: 20, height: 20,
                  child: CircularProgressIndicator(color: AppTheme.primary, strokeWidth: 2)))
            : TextButton(
                onPressed: _save,
                child: const Text('Creer', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700, fontSize: 16))),
      ]),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      // Nom de la route
      const Text('Nom de la route', style: TextStyle(color: AppTheme.textMuted, fontSize: 12, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      TextField(
        controller: _nameCtrl,
        style: const TextStyle(color: AppTheme.textPrimary),
        decoration: const InputDecoration(hintText: 'Ex: Route matin Bruxelles')),
      const SizedBox(height: 28),

      // Stops
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Stops', style: TextStyle(color: AppTheme.textMuted, fontSize: 12, fontWeight: FontWeight.w600)),
        Text('${_stops.length} ajoutee(s)', style: const TextStyle(color: AppTheme.textFaint, fontSize: 12)),
      ]),
      const SizedBox(height: 12),

      if (_stops.isEmpty)
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppTheme.surfaceDark, borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.borderDark, style: BorderStyle.solid)),
          child: Column(children: [
            const Icon(Icons.add_location_rounded, color: AppTheme.textFaint, size: 40),
            const SizedBox(height: 12),
            const Text('Aucun stop pour l\'instant', style: TextStyle(color: AppTheme.textMuted, fontSize: 14)),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _addStop,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Ajouter le premier stop'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary, foregroundColor: AppTheme.bgDark,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))),
          ])),

      ..._stops.asMap().entries.map((e) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: _StopForm(
          key: ValueKey(e.key),
          index: e.key + 1,
          input: e.value,
          onDelete: () => setState(() => _stops.removeAt(e.key)),
          onChange: () => setState(() {})))),

      if (_stops.isNotEmpty)
        TextButton.icon(
          onPressed: _addStop,
          icon: const Icon(Icons.add_rounded, color: AppTheme.primary),
          label: const Text('Ajouter un stop', style: TextStyle(color: AppTheme.primary, fontSize: 14))),
      const SizedBox(height: 100),
    ]),
  );
}

class _StopInput {
  String address = '', client = '', phone = '', notes = '';
}

class _StopForm extends StatefulWidget {
  final int index;
  final _StopInput input;
  final VoidCallback onDelete, onChange;
  const _StopForm({super.key, required this.index, required this.input,
    required this.onDelete, required this.onChange});
  @override State<_StopForm> createState() => _StopFormState();
}

class _StopFormState extends State<_StopForm> {
  bool _expanded = true;

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: AppTheme.surfaceDark, borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppTheme.borderDark)),
    child: Column(children: [
      // Header
      GestureDetector(
        onTap: () => setState(() => _expanded = !_expanded),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(children: [
            Container(
              width: 28, height: 28,
              decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
              child: Center(child: Text('${widget.index}',
                style: const TextStyle(color: AppTheme.primary, fontSize: 13, fontWeight: FontWeight.w700)))),
            const SizedBox(width: 10),
            Expanded(child: Text(
              widget.input.address.isEmpty ? 'Stop ${widget.index}' : widget.input.address,
              style: TextStyle(
                color: widget.input.address.isEmpty ? AppTheme.textFaint : AppTheme.textPrimary,
                fontSize: 14, fontWeight: FontWeight.w600),
              overflow: TextOverflow.ellipsis)),
            Icon(_expanded ? Icons.expand_less_rounded : Icons.expand_more_rounded,
              color: AppTheme.textFaint),
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded, color: AppTheme.error, size: 20),
              onPressed: widget.onDelete, padding: EdgeInsets.zero,
              constraints: const BoxConstraints(maxWidth: 32)),
          ]))),

      if (_expanded) Padding(
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        child: Column(children: [
          const Divider(color: AppTheme.borderDark, height: 1),
          const SizedBox(height: 12),
          _field('Adresse *', Icons.location_on_rounded, (v) { widget.input.address = v; widget.onChange(); }, autofocus: true),
          const SizedBox(height: 10),
          _field('Nom du client', Icons.person_rounded, (v) { widget.input.client = v; widget.onChange(); }),
          const SizedBox(height: 10),
          _field('Telephone', Icons.phone_rounded, (v) { widget.input.phone = v; widget.onChange(); },
            keyboard: TextInputType.phone),
          const SizedBox(height: 10),
          _field('Notes', Icons.note_rounded, (v) { widget.input.notes = v; widget.onChange(); }),
        ])),
    ]),
  );

  Widget _field(String hint, IconData icon, Function(String) onChanged,
      {bool autofocus = false, TextInputType keyboard = TextInputType.text}) =>
    TextField(
      autofocus: autofocus,
      keyboardType: keyboard,
      onChanged: onChanged,
      style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
      decoration: InputDecoration(
        hintText: hint, prefixIcon: Icon(icon, color: AppTheme.textFaint, size: 18),
        contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12)));
}
