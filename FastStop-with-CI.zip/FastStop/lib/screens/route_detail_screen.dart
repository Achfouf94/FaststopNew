import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/route_model.dart';
import '../models/stop_model.dart';
import '../services/route_provider.dart';
import '../utils/app_theme.dart';
import '../widgets/stop_tile.dart';
import 'active_route_screen.dart';

class RouteDetailScreen extends StatelessWidget {
  final DeliveryRoute route;
  const RouteDetailScreen({super.key, required this.route});

  double _estDist(List<Stop> stops) {
    double t = 0;
    for (final s in stops) { if (s.distanceFromPrev != null) t += s.distanceFromPrev!; }
    return t > 0 ? t : stops.length * 1.2;
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<RouteProvider>();
    final live = provider.routes.firstWhere((r) => r.id == route.id, orElse: () => route);
    final isDraft = live.status == RouteStatus.draft;
    final dist = live.totalDistanceKm > 0 ? live.totalDistanceKm : _estDist(live.stops);
    final estMin = (dist / 24 * 60 + live.stops.length * 3).round();

    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceDark,
        title: Text(live.name, style: const TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w700)),
        actions: [
          if (isDraft && !provider.isOptimizing)
            IconButton(
              icon: const Icon(Icons.auto_awesome_rounded, color: AppTheme.primary),
              onPressed: () => provider.optimizeRoute(live), tooltip: 'Optimiser'),
          if (provider.isOptimizing)
            const Padding(padding: EdgeInsets.all(16),
              child: SizedBox(width: 20, height: 20,
                child: CircularProgressIndicator(color: AppTheme.primary, strokeWidth: 2))),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded, color: AppTheme.error),
            onPressed: () => _confirmDelete(context, provider, live)),
        ]),
      body: Column(children: [
        // Stats bar
        Container(
          color: AppTheme.surfaceDark,
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Row(children: [
            _Stat('Stops', '${live.stops.length}', Icons.location_on_rounded, AppTheme.accent),
            Container(width: 1, height: 36, color: AppTheme.borderDark),
            _Stat('~${dist.toStringAsFixed(1)} km', 'Distance', Icons.straighten_rounded, AppTheme.textMuted),
            Container(width: 1, height: 36, color: AppTheme.borderDark),
            _Stat('~${estMin}min', 'Duree est.', Icons.schedule_rounded, AppTheme.warning),
          ])),
        Expanded(
          child: live.stops.isEmpty
              ? const Center(child: Text('Aucun stop', style: TextStyle(color: AppTheme.textMuted)))
              : ReorderableListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                  itemCount: live.stops.length,
                  onReorder: isDraft ? (o, n) => provider.reorderStops(live, o, n) : (_, __) {},
                  itemBuilder: (ctx, i) => Padding(
                    key: ValueKey(live.stops[i].id),
                    padding: const EdgeInsets.only(bottom: 8),
                    child: StopTile(
                      stop: live.stops[i], index: i + 1,
                      isReadOnly: !isDraft && live.status == RouteStatus.completed,
                      onStatusChange: live.status == RouteStatus.active
                          ? (s, r) => provider.updateStopStatus(live.stops[i], s, reason: r) : null,
                      onNavigate: live.status == RouteStatus.active
                          ? () => provider.navigateToStop(live.stops[i]) : null)))),
      ]),
      floatingActionButton: isDraft && live.stops.isNotEmpty
          ? FloatingActionButton.extended(
              backgroundColor: AppTheme.primary, foregroundColor: AppTheme.bgDark,
              onPressed: () async {
                await provider.startRoute(live);
                if (context.mounted) Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (_) => ActiveRouteScreen(route: live)));
              },
              icon: const Icon(Icons.play_arrow_rounded),
              label: const Text('Demarrer', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)))
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  void _confirmDelete(BuildContext ctx, RouteProvider p, DeliveryRoute r) =>
    showDialog(context: ctx, builder: (_) => AlertDialog(
      backgroundColor: AppTheme.surfaceDark,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Supprimer ?', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w700)),
      content: const Text('Cette action est irreversible.', style: TextStyle(color: AppTheme.textMuted)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx),
          child: const Text('Annuler', style: TextStyle(color: AppTheme.textMuted))),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error, foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          onPressed: () { p.deleteRoute(r.id); Navigator.pop(ctx); Navigator.pop(ctx); },
          child: const Text('Supprimer', style: TextStyle(fontWeight: FontWeight.w700))),
      ]));
}

class _Stat extends StatelessWidget {
  final String value, label; final IconData icon; final Color color;
  const _Stat(this.value, this.label, this.icon, this.color);
  @override
  Widget build(BuildContext context) => Expanded(child: Column(children: [
    Icon(icon, color: color, size: 18),
    const SizedBox(height: 4),
    Text(value, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w700)),
    Text(label, style: const TextStyle(color: AppTheme.textMuted, fontSize: 10)),
  ]));
}
