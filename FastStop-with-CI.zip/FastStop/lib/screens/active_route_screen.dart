import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/route_model.dart';
import '../models/stop_model.dart';
import '../services/route_provider.dart';
import '../utils/app_theme.dart';
import '../widgets/stop_tile.dart';

class ActiveRouteScreen extends StatelessWidget {
  final DeliveryRoute route;
  const ActiveRouteScreen({super.key, required this.route});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<RouteProvider>();
    final live = provider.routes.firstWhere((r) => r.id == route.id, orElse: () => route);
    final remaining = live.stops.where((s) => s.status == StopStatus.pending).length;
    final progress = live.stops.isEmpty ? 0.0 : (live.deliveredCount / live.stops.length);

    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceDark,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(live.name, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
          Text('$remaining restants', style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
        ]),
        actions: [
          if (remaining == 0)
            TextButton.icon(
              onPressed: () async {
                await provider.completeRoute(live);
                if (context.mounted) Navigator.popUntil(context, (r) => r.isFirst);
              },
              icon: const Icon(Icons.flag_rounded, color: AppTheme.primary, size: 18),
              label: const Text('Terminer', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700))),
        ]),
      body: Column(children: [
        // Progress bar
        Container(
          color: AppTheme.surfaceDark,
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: progress,
                backgroundColor: AppTheme.borderDark,
                valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primary),
                minHeight: 6)),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${live.deliveredCount} livres · ${live.failedCount} echecs',
                style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
              Text('${(progress * 100).round()}%',
                style: const TextStyle(color: AppTheme.primary, fontSize: 12, fontWeight: FontWeight.w700)),
            ]),
          ])),

        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 80),
            itemCount: live.stops.length,
            itemBuilder: (ctx, i) {
              final stop = live.stops[i];
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: StopTile(
                  stop: stop, index: i + 1,
                  onStatusChange: stop.status == StopStatus.pending
                      ? (s, r) => provider.updateStopStatus(stop, s, reason: r) : null,
                  onNavigate: stop.status == StopStatus.pending
                      ? () => provider.navigateToStop(stop) : null));
            })),
      ]),
      floatingActionButton: remaining > 0 ? null : FloatingActionButton.extended(
        backgroundColor: AppTheme.primary, foregroundColor: AppTheme.bgDark,
        onPressed: () async {
          await provider.completeRoute(live);
          if (context.mounted) Navigator.popUntil(context, (r) => r.isFirst);
        },
        icon: const Icon(Icons.flag_rounded),
        label: const Text('Terminer la route', style: TextStyle(fontWeight: FontWeight.w700))),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
