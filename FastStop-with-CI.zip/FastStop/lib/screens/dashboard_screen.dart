import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/route_provider.dart';
import '../models/route_model.dart';
import '../utils/app_theme.dart';
import '../widgets/stat_card.dart';
import '../widgets/route_card.dart';
import 'create_route_screen.dart';
import 'route_detail_screen.dart';
import 'active_route_screen.dart';
import 'history_screen.dart';
import 'settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _tab = 0;

  final _pages = const [_HomeTab(), HistoryScreen(), SettingsScreen()];

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    body: _pages[_tab],
    bottomNavigationBar: Container(
      decoration: const BoxDecoration(
        color: AppTheme.surfaceDark,
        border: Border(top: BorderSide(color: AppTheme.borderDark))),
      child: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Accueil'),
          BottomNavigationBarItem(icon: Icon(Icons.history_rounded), label: 'Historique'),
          BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: 'Parametres'),
        ])),
    floatingActionButton: _tab == 0
        ? FloatingActionButton(
            onPressed: () async {
              final provider = context.read<RouteProvider>();
              await Navigator.push(context,
                MaterialPageRoute(builder: (_) => const CreateRouteScreen()));
            },
            backgroundColor: AppTheme.primary,
            foregroundColor: AppTheme.bgDark,
            child: const Icon(Icons.add_rounded, size: 28))
        : null,
  );
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<RouteProvider>();
    final today = DateTime.now();
    final todayRoutes = provider.routes
        .where((r) => r.date.day == today.day && r.date.month == today.month && r.date.year == today.year)
        .toList();
    final active = provider.activeRoute;
    final totalToday = todayRoutes.fold(0, (s, r) => s + r.stops.length);
    final delivToday = todayRoutes.fold(0, (s, r) => s + r.deliveredCount);
    final rateToday = totalToday > 0 ? ((delivToday / totalToday) * 100).round() : 0;

    return SafeArea(
      child: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(DateFormat('EEEE d MMMM', 'fr_FR').format(today),
                style: const TextStyle(color: AppTheme.textMuted, fontSize: 13)),
              const SizedBox(height: 4),
              RichText(text: const TextSpan(children: [
                TextSpan(text: 'Fast', style: TextStyle(color: AppTheme.textPrimary, fontSize: 22, fontWeight: FontWeight.w800)),
                TextSpan(text: 'Stop', style: TextStyle(color: AppTheme.primary, fontSize: 22, fontWeight: FontWeight.w800)),
              ])),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.primary.withOpacity(0.12),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.primary.withOpacity(0.2))),
              child: Row(children: [
                const Icon(Icons.local_shipping_rounded, color: AppTheme.primary, size: 14),
                const SizedBox(width: 6),
                Text('$rateToday%', style: const TextStyle(color: AppTheme.primary, fontSize: 13, fontWeight: FontWeight.w700)),
              ])),
          ]))),

        // ─── ROUTE ACTIVE ──────────────────────────────────────────────────────
        if (active != null)
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: GestureDetector(
              onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => ActiveRouteScreen(route: active))),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.accent.withOpacity(0.25), AppTheme.primary.withOpacity(0.15)]),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.accent.withOpacity(0.4))),
                child: Row(children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.accent.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.navigation_rounded, color: AppTheme.accent, size: 24)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Route en cours', style: TextStyle(color: AppTheme.accent, fontSize: 12, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 2),
                    Text(active.name, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 15, fontWeight: FontWeight.w700)),
                    Text('${active.deliveredCount}/${active.stops.length} stops',
                      style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
                  ])),
                  const Icon(Icons.chevron_right_rounded, color: AppTheme.accent),
                ]),
              )))),

        // ─── STATS DU JOUR ─────────────────────────────────────────────────────
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(children: [
            Expanded(child: StatCard(label: 'Livres auj.', value: '$delivToday',
              icon: Icons.check_circle_rounded, color: AppTheme.primary,
              subtitle: '$totalToday stops total')),
            const SizedBox(width: 12),
            Expanded(child: StatCard(label: 'Routes auj.', value: '${todayRoutes.length}',
              icon: Icons.route_rounded, color: AppTheme.accent)),
          ]))),

        // ─── ROUTES DU JOUR ────────────────────────────────────────────────────
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text("Aujourd'hui",
              style: TextStyle(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
            if (todayRoutes.isEmpty)
              TextButton(
                onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const CreateRouteScreen())),
                child: const Text('Creer une route', style: TextStyle(color: AppTheme.primary, fontSize: 13))),
          ]))),

        if (todayRoutes.isEmpty)
          const SliverToBoxAdapter(child: Padding(
            padding: EdgeInsets.symmetric(vertical: 40),
            child: Center(child: Column(children: [
              Icon(Icons.inbox_rounded, size: 48, color: AppTheme.textFaint),
              SizedBox(height: 12),
              Text('Aucune route pour aujourd\'hui',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 14)),
              SizedBox(height: 4),
              Text('Appuie sur + pour commencer',
                style: TextStyle(color: AppTheme.textFaint, fontSize: 12)),
            ]))))
        else
          SliverList(delegate: SliverChildBuilderDelegate(
            (ctx, i) {
              final r = todayRoutes[i];
              return Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: RouteCard(
                  route: r,
                  onTap: () => Navigator.push(ctx, MaterialPageRoute(
                    builder: (_) => r.status == RouteStatus.active
                        ? ActiveRouteScreen(route: r)
                        : RouteDetailScreen(route: r)))));
            },
            childCount: todayRoutes.length)),

        // ─── AUTRES ROUTES ─────────────────────────────────────────────────────
        if (provider.routes.where((r) => !(r.date.day == today.day && r.date.month == today.month && r.date.year == today.year)).isNotEmpty) ...[
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
            child: const Text('Routes recentes',
              style: TextStyle(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)))),
          SliverList(delegate: SliverChildBuilderDelegate(
            (ctx, i) {
              final others = provider.routes.where((r) => !(r.date.day == today.day && r.date.month == today.month && r.date.year == today.year)).toList();
              if (i >= others.length) return null;
              return Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                child: RouteCard(
                  route: others[i],
                  onTap: () => Navigator.push(ctx, MaterialPageRoute(
                    builder: (_) => RouteDetailScreen(route: others[i])))));
            },
            childCount: provider.routes.where((r) => !(r.date.day == today.day && r.date.month == today.month && r.date.year == today.year)).length)),
        ],

        const SliverPadding(padding: EdgeInsets.only(bottom: 80)),
      ]),
    );
  }
}
