import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/route_provider.dart';
import '../services/geo_service.dart';
import '../utils/app_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final provider = context.watch<RouteProvider>();
    return SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Parametres',
        style: TextStyle(color: AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w800)),
      const SizedBox(height: 28),
      const _Header('Navigation GPS'),
      const SizedBox(height: 12),
      Container(
        decoration: BoxDecoration(color: AppTheme.surfaceDark, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.borderDark)),
        child: Column(children: MapApp.values.map((app) {
          final sel = provider.preferredMapApp == app;
          return ListTile(
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: sel ? AppTheme.primary.withOpacity(0.15) : AppTheme.surface2,
                borderRadius: BorderRadius.circular(10)),
              child: Icon(_icon(app), color: sel ? AppTheme.primary : AppTheme.textMuted, size: 22)),
            title: Text(_name(app),
              style: TextStyle(color: sel ? AppTheme.textPrimary : AppTheme.textMuted,
                fontWeight: sel ? FontWeight.w600 : FontWeight.normal)),
            trailing: sel ? const Icon(Icons.check_circle_rounded, color: AppTheme.primary) : null,
            onTap: () => provider.setMapApp(app));
        }).toList())),
      const SizedBox(height: 28),
      const _Header('Application'),
      const SizedBox(height: 12),
      Container(
        decoration: BoxDecoration(color: AppTheme.surfaceDark, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.borderDark)),
        child: const Column(children: [
          _Info(Icons.info_outline_rounded, 'Version', '1.0.0'),
          _Info(Icons.location_city_rounded, 'Zone', 'Bruxelles, Belgique'),
          _Info(Icons.speed_rounded, 'Vitesse moy. ville', '24 km/h'),
          _Info(Icons.timer_rounded, 'Temps par stop', '3 minutes'),
        ])),
      const SizedBox(height: 28),
      const _Header("Algorithme d'optimisation"),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppTheme.surfaceDark, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.borderDark)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(Icons.auto_awesome_rounded, color: AppTheme.primary, size: 18),
            SizedBox(width: 8),
            Text('Nearest Neighbor + 2-opt',
              style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w600)),
          ]),
          SizedBox(height: 8),
          Text(
            'Algorithme TSP heuristic avec amelioration 2-opt. Geocodage via OpenStreetMap Nominatim, gratuit et sans cle API. Fonctionne 100% hors-ligne apres geocodage.',
            style: TextStyle(color: AppTheme.textMuted, fontSize: 13, height: 1.5)),
        ])),
      const SizedBox(height: 40),
      Center(child: Column(children: [
        RichText(text: const TextSpan(children: [
          TextSpan(text: 'Fast', style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w800, fontSize: 20)),
          TextSpan(text: 'Stop', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w800, fontSize: 20)),
        ])),
        const SizedBox(height: 4),
        const Text('Optimise pour Bruxelles', style: TextStyle(color: AppTheme.textFaint, fontSize: 12)),
      ])),
      const SizedBox(height: 32),
    ]));
  }

  IconData _icon(MapApp a) { switch (a) { case MapApp.appleMaps: return Icons.map_rounded; case MapApp.googleMaps: return Icons.location_on_rounded; case MapApp.waze: return Icons.navigation_rounded; } }
  String _name(MapApp a) { switch (a) { case MapApp.appleMaps: return 'Apple Maps'; case MapApp.googleMaps: return 'Google Maps'; case MapApp.waze: return 'Waze'; } }
}

class _Header extends StatelessWidget {
  final String t; const _Header(this.t);
  @override Widget build(_) => Text(t, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 0.8));
}

class _Info extends StatelessWidget {
  final IconData icon; final String label, value;
  const _Info(this.icon, this.label, this.value);
  @override Widget build(_) => ListTile(
    leading: Icon(icon, color: AppTheme.textMuted, size: 20),
    title: Text(label, style: const TextStyle(color: AppTheme.textMuted, fontSize: 14)),
    trailing: Text(value, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)));
}
