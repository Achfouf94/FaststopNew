import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/route_provider.dart';
import '../models/route_model.dart';
import '../utils/app_theme.dart';
import '../widgets/route_card.dart';
import 'route_detail_screen.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final provider = context.watch<RouteProvider>();
    final done = provider.routes.where((r) => r.status == RouteStatus.completed).toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    final totalDel = done.fold(0, (s, r) => s + r.deliveredCount);
    final totalKm = done.fold(0.0, (s, r) => s + r.totalDistanceKm);
    final avgRate = done.isEmpty ? 0.0
        : done.fold(0.0, (s, r) => s + r.completionRate) / done.length;

    return SafeArea(child: CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
        child: const Text('Historique',
          style: TextStyle(color: AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w800)))),
      if (done.isNotEmpty) SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.surfaceDark, borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.borderDark)),
          child: Row(children: [
            _GS('Routes', '${done.length}', AppTheme.textPrimary),
            _GS('Livres', '$totalDel', AppTheme.primary),
            _GS('Taux moy.', '${avgRate.round()}%', AppTheme.accent),
            _GS('Km total', '${totalKm.toStringAsFixed(0)}', AppTheme.textMuted),
          ])))),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
        child: Text('${done.length} route(s) terminee(s)',
          style: const TextStyle(color: AppTheme.textMuted, fontSize: 13)))),
      if (done.isEmpty)
        SliverFillRemaining(child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.history_rounded, size: 56, color: AppTheme.textFaint),
          const SizedBox(height: 16),
          const Text('Aucune route terminee', style: TextStyle(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text('Tes routes completees apparaitront ici', style: TextStyle(color: AppTheme.textMuted, fontSize: 13)),
        ])))
      else
        SliverList(delegate: SliverChildBuilderDelegate(
          (ctx, i) => Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
            child: RouteCard(route: done[i],
              onTap: () => Navigator.push(ctx,
                MaterialPageRoute(builder: (_) => RouteDetailScreen(route: done[i]))))),
          childCount: done.length)),
      const SliverPadding(padding: EdgeInsets.only(bottom: 32)),
    ]));
  }
}

class _GS extends StatelessWidget {
  final String l, v; final Color c;
  const _GS(this.l, this.v, this.c);
  @override
  Widget build(BuildContext context) => Expanded(child: Column(children: [
    Text(v, style: TextStyle(color: c, fontSize: 18, fontWeight: FontWeight.w800)),
    const SizedBox(height: 3),
    Text(l, style: const TextStyle(color: AppTheme.textMuted, fontSize: 11)),
  ]));
}
