import 'package:flutter/foundation.dart';
import '../models/route_model.dart';
import '../models/stop_model.dart';
import 'database_service.dart';
import 'route_optimizer.dart';
import 'geo_service.dart';

class RouteProvider extends ChangeNotifier {
  final _db = DatabaseService();
  List<DeliveryRoute> _routes = [];
  bool _loading = false, _optimizing = false;
  MapApp _mapApp = MapApp.appleMaps;

  List<DeliveryRoute> get routes => _routes;
  bool get isLoading => _loading;
  bool get isOptimizing => _optimizing;
  MapApp get preferredMapApp => _mapApp;

  DeliveryRoute? get activeRoute {
    try { return _routes.firstWhere((r) => r.status == RouteStatus.active); }
    catch (_) { return null; }
  }

  int get todayDelivered {
    final today = DateTime.now();
    return _routes
      .where((r) => r.date.day == today.day && r.date.month == today.month && r.date.year == today.year)
      .fold(0, (s, r) => s + r.deliveredCount);
  }

  Future<void> loadRoutes() async {
    _loading = true; notifyListeners();
    _routes = await _db.getAllRoutes();
    _loading = false; notifyListeners();
  }

  Future<DeliveryRoute> createRoute(String name, {DateTime? date}) async {
    final r = DeliveryRoute(name: name, date: date ?? DateTime.now());
    await _db.insertRoute(r);
    _routes.insert(0, r); notifyListeners();
    return r;
  }

  Future<void> startRoute(DeliveryRoute route) async {
    final i = _idx(route.id); if (i < 0) return;
    _routes[i] = DeliveryRoute(
      id: route.id, name: route.name, date: route.date,
      status: RouteStatus.active, stops: route.stops,
      startedAt: DateTime.now(), totalStops: route.stops.length);
    await _db.updateRoute(_routes[i]); notifyListeners();
  }

  Future<void> completeRoute(DeliveryRoute route) async {
    final i = _idx(route.id); if (i < 0) return;
    final dist = RouteOptimizer.totalDistance(route.stops);
    _routes[i] = DeliveryRoute(
      id: route.id, name: route.name, date: route.date,
      status: RouteStatus.completed, stops: route.stops,
      startedAt: route.startedAt, completedAt: DateTime.now(),
      totalDistanceKm: dist, totalStops: route.stops.length);
    await _db.updateRoute(_routes[i]); notifyListeners();
  }

  Future<void> deleteRoute(String id) async {
    await _db.deleteRoute(id); _routes.removeWhere((r) => r.id == id); notifyListeners();
  }

  Future<void> addStop(DeliveryRoute route, Stop stop) async {
    await _db.insertStop(route.id, stop); route.stops.add(stop); notifyListeners();
  }

  Future<void> updateStopStatus(Stop stop, StopStatus status, {String? reason}) async {
    final u = stop.copyWith(
      status: status,
      completedAt: status == StopStatus.delivered ? DateTime.now() : null,
      failureReason: reason);
    await _db.updateStop(u); _replaceStop(u); notifyListeners();
  }

  Future<void> updateStop(Stop stop) async {
    await _db.updateStop(stop); _replaceStop(stop); notifyListeners();
  }

  Future<void> deleteStop(DeliveryRoute route, String stopId) async {
    await _db.deleteStop(stopId); route.stops.removeWhere((s) => s.id == stopId); notifyListeners();
  }

  Future<void> reorderStops(DeliveryRoute route, int oi, int ni) async {
    final s = List<Stop>.from(route.stops);
    if (ni > oi) ni--;
    s.insert(ni, s.removeAt(oi));
    for (int i = 0; i < s.length; i++) s[i] = s[i].copyWith(order: i);
    route.stops..clear()..addAll(s);
    await _db.reorderStops(route.id, s); notifyListeners();
  }

  Future<void> optimizeRoute(DeliveryRoute route) async {
    _optimizing = true; notifyListeners();
    try {
      for (int i = 0; i < route.stops.length; i++) {
        final stop = route.stops[i];
        if (stop.latitude == null) {
          final c = await GeoService.geocode(stop.address);
          if (c != null) {
            route.stops[i] = stop.copyWith(latitude: c['lat'], longitude: c['lng']);
            await _db.updateStop(route.stops[i]);
          }
          await Future.delayed(const Duration(milliseconds: 1100));
        }
      }
      final pos = await GeoService.getPosition();
      var opt = RouteOptimizer.optimize(route.stops,
        startLat: pos?.latitude ?? 50.8503, startLng: pos?.longitude ?? 4.3517);
      opt = RouteOptimizer.twoOpt(opt);
      route.stops..clear()..addAll(opt);
      await _db.reorderStops(route.id, opt);
    } catch (_) {} finally { _optimizing = false; notifyListeners(); }
  }

  Future<void> navigateToStop(Stop stop) async {
    final c = stop.latitude == null ? await GeoService.geocode(stop.address) : null;
    final lat = stop.latitude ?? c?['lat']; final lng = stop.longitude ?? c?['lng'];
    if (lat != null) await GeoService.navigateTo(lat, lng!, stop.address, _mapApp);
  }

  void setMapApp(MapApp app) { _mapApp = app; notifyListeners(); }
  int _idx(String id) => _routes.indexWhere((r) => r.id == id);
  void _replaceStop(Stop u) {
    for (final r in _routes) {
      final i = r.stops.indexWhere((s) => s.id == u.id);
      if (i >= 0) { r.stops[i] = u; return; }
    }
  }
}
