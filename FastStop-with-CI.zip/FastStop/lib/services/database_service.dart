import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/stop_model.dart';
import '../models/route_model.dart';

class DatabaseService {
  static final DatabaseService _i = DatabaseService._();
  factory DatabaseService() => _i;
  DatabaseService._();
  static Database? _db;

  Future<Database> get database async { _db ??= await _init(); return _db!; }

  Future<Database> _init() async {
    final p = join(await getDatabasesPath(), 'faststop.db');
    return openDatabase(p, version: 1, onCreate: (db, _) async {
      await db.execute('''CREATE TABLE routes(
        id TEXT PRIMARY KEY, name TEXT NOT NULL, date INTEGER NOT NULL,
        status INTEGER DEFAULT 0, startAddress TEXT, startedAt INTEGER,
        completedAt INTEGER, totalDistanceKm REAL DEFAULT 0, totalStops INTEGER DEFAULT 0)''');
      await db.execute('''CREATE TABLE stops(
        id TEXT PRIMARY KEY, routeId TEXT NOT NULL, address TEXT NOT NULL,
        clientName TEXT, clientPhone TEXT, notes TEXT,
        status INTEGER DEFAULT 0, priority INTEGER DEFAULT 0,
        "order" INTEGER NOT NULL, latitude REAL, longitude REAL,
        completedAt INTEGER, failureReason TEXT, photos TEXT,
        packageRef TEXT, isVisited INTEGER DEFAULT 0, distanceFromPrev REAL,
        FOREIGN KEY(routeId) REFERENCES routes(id) ON DELETE CASCADE)''');
    });
  }

  Future<void> insertRoute(DeliveryRoute r) async =>
    (await database).insert('routes', r.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);

  Future<List<DeliveryRoute>> getAllRoutes() async {
    final rows = await (await database).query('routes', orderBy: 'date DESC');
    final out = <DeliveryRoute>[];
    for (final row in rows) {
      out.add(DeliveryRoute.fromMap(row, stops: await getStopsByRoute(row['id'] as String)));
    }
    return out;
  }

  Future<List<Stop>> getStopsByRoute(String rid) async {
    final rows = await (await database).query('stops',
      where: 'routeId=?', whereArgs: [rid], orderBy: '"order" ASC');
    return rows.map(Stop.fromMap).toList();
  }

  Future<void> updateRoute(DeliveryRoute r) async =>
    (await database).update('routes', r.toMap(), where: 'id=?', whereArgs: [r.id]);

  Future<void> deleteRoute(String id) async {
    final db = await database;
    await db.delete('routes', where: 'id=?', whereArgs: [id]);
    await db.delete('stops', where: 'routeId=?', whereArgs: [id]);
  }

  Future<void> insertStop(String rid, Stop s) async {
    final m = s.toMap()..['routeId'] = rid;
    await (await database).insert('stops', m, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> updateStop(Stop s) async =>
    (await database).update('stops', s.toMap(), where: 'id=?', whereArgs: [s.id]);

  Future<void> deleteStop(String id) async =>
    (await database).delete('stops', where: 'id=?', whereArgs: [id]);

  Future<void> reorderStops(String rid, List<Stop> stops) async {
    final b = (await database).batch();
    for (int i = 0; i < stops.length; i++)
      b.update('stops', {'order': i}, where: 'id=?', whereArgs: [stops[i].id]);
    await b.commit(noResult: true);
  }
}
