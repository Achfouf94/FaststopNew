import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';

enum MapApp { appleMaps, googleMaps, waze }

class GeoService {
  static const _base = 'https://nominatim.openstreetmap.org';

  static Future<Map<String, double>?> geocode(String address) async {
    try {
      final q = Uri.encodeComponent('$address, Bruxelles, Belgique');
      final r = await http.get(
        Uri.parse('$_base/search?q=$q&format=json&limit=1&countrycodes=be'),
        headers: {'User-Agent': 'FastStop/1.0'},
      ).timeout(const Duration(seconds: 8));
      if (r.statusCode == 200) {
        final d = json.decode(r.body) as List;
        if (d.isNotEmpty) return {'lat': double.parse(d[0]['lat']), 'lng': double.parse(d[0]['lon'])};
      }
    } catch (_) {}
    return null;
  }

  static Future<Position?> getPosition() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied || p == LocationPermission.deniedForever) return null;
      return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    } catch (_) { return null; }
  }

  static Future<void> navigateTo(double lat, double lng, String address, MapApp app) async {
    Uri uri;
    if (app == MapApp.appleMaps) uri = Uri.parse('maps://?daddr=$lat,$lng&dirflg=d');
    else if (app == MapApp.googleMaps) uri = Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=driving');
    else uri = Uri.parse('waze://?ll=$lat,$lng&navigate=yes');
    if (await canLaunchUrl(uri)) { await launchUrl(uri, mode: LaunchMode.externalApplication); return; }
    final fb = Uri.parse('https://www.google.com/maps/dir/?api=1&destination=${Uri.encodeComponent(address)}');
    await launchUrl(fb, mode: LaunchMode.externalApplication);
  }

  static Future<void> call(String phone) async {
    final u = Uri.parse('tel:$phone');
    if (await canLaunchUrl(u)) await launchUrl(u);
  }
}
