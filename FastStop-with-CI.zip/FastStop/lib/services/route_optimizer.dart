import 'dart:math';
import '../models/stop_model.dart';

class RouteOptimizer {
  static const _bLat = 50.8503, _bLng = 4.3517;

  static List<Stop> optimize(List<Stop> stops,
      {double startLat = _bLat, double startLng = _bLng}) {
    if (stops.length <= 2) return stops;
    final rem = List<Stop>.from(stops);
    final out = <Stop>[];
    double cLat = startLat, cLng = startLng;
    while (rem.isNotEmpty) {
      final wc = rem.where((s) => s.latitude != null).toList();
      if (wc.isEmpty) { out.addAll(rem); rem.clear(); break; }
      var near = wc.first; var md = double.infinity;
      for (final s in wc) {
        final d = _hav(cLat, cLng, s.latitude!, s.longitude!);
        if (d < md) { md = d; near = s; }
      }
      rem.remove(near);
      out.add(near.copyWith(order: out.length, distanceFromPrev: md));
      cLat = near.latitude!; cLng = near.longitude!;
    }
    for (int i = 0; i < out.length; i++) out[i] = out[i].copyWith(order: i);
    return out;
  }

  static List<Stop> twoOpt(List<Stop> stops) {
    final s = stops.where((x) => x.latitude != null).toList();
    if (s.length < 4) return stops;
    var cur = List<Stop>.from(s); bool imp = true;
    while (imp) {
      imp = false;
      for (int i = 0; i < cur.length - 1; i++) {
        for (int j = i + 2; j < cur.length; j++) {
          final d1 = _d(cur,i,i+1) + _d(cur,j,(j+1)%cur.length);
          final d2 = _d(cur,i,j) + _d(cur,i+1,(j+1)%cur.length);
          if (d2 < d1 - 0.001) {
            cur = [...cur.sublist(0,i+1),...cur.sublist(i+1,j+1).reversed,...cur.sublist(j+1)];
            imp = true;
          }
        }
      }
    }
    for (int i = 0; i < cur.length; i++) cur[i] = cur[i].copyWith(order: i);
    return cur;
  }

  static double _d(List<Stop> s, int i, int j) {
    final jj = j % s.length;
    if (s[i].latitude == null || s[jj].latitude == null) return 0;
    return _hav(s[i].latitude!, s[i].longitude!, s[jj].latitude!, s[jj].longitude!);
  }

  static double totalDistance(List<Stop> stops,
      {double startLat = _bLat, double startLng = _bLng}) {
    double tot = 0, pLat = startLat, pLng = startLng;
    for (final s in stops) {
      if (s.latitude != null) {
        tot += _hav(pLat, pLng, s.latitude!, s.longitude!);
        pLat = s.latitude!; pLng = s.longitude!;
      }
    }
    return tot;
  }

  static double _hav(double a, double b, double c, double d) {
    const R = 6371.0;
    final dLat = (c-a)*pi/180, dLng = (d-b)*pi/180;
    final x = sin(dLat/2)*sin(dLat/2)+cos(a*pi/180)*cos(c*pi/180)*sin(dLng/2)*sin(dLng/2);
    return R*2*atan2(sqrt(x),sqrt(1-x));
  }
}
