import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const primary     = Color(0xFF00C896);
  static const primaryDark = Color(0xFF00A87A);
  static const accent      = Color(0xFF4F8EF7);
  static const warning     = Color(0xFFFFA726);
  static const error       = Color(0xFFEF5350);
  static const bgDark      = Color(0xFF0F1117);
  static const surfaceDark = Color(0xFF1A1D26);
  static const surface2    = Color(0xFF232738);
  static const borderDark  = Color(0xFF2E3347);
  static const textPrimary = Color(0xFFE8EAF0);
  static const textMuted   = Color(0xFF8B90A4);
  static const textFaint   = Color(0xFF4A4F63);

  static Color statusColor(StopStatusX s) {
    switch (s) {
      case StopStatusX.delivered: return primary;
      case StopStatusX.failed:    return error;
      case StopStatusX.absent:    return warning;
      case StopStatusX.postponed: return accent;
      default: return textFaint;
    }
  }

  static ThemeData get dark => ThemeData(
    useMaterial3: true, brightness: Brightness.dark,
    scaffoldBackgroundColor: bgDark,
    colorScheme: const ColorScheme.dark(
      primary: primary, secondary: accent, error: error,
      surface: surfaceDark, onPrimary: bgDark, onSurface: textPrimary),
    textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
    appBarTheme: AppBarTheme(
      backgroundColor: bgDark, elevation: 0, scrolledUnderElevation: 0,
      systemOverlayStyle: SystemUiOverlayStyle.light,
      titleTextStyle: GoogleFonts.inter(color: textPrimary, fontSize: 18, fontWeight: FontWeight.w700),
      iconTheme: const IconThemeData(color: textPrimary)),
    cardTheme: CardTheme(
      color: surfaceDark, elevation: 0, margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16), side: const BorderSide(color: borderDark))),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: surfaceDark, selectedItemColor: primary,
      unselectedItemColor: textMuted, type: BottomNavigationBarType.fixed, elevation: 0),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: primary, foregroundColor: bgDark, elevation: 4),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: surface2,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: borderDark)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: borderDark)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: primary, width: 2)),
      hintStyle: const TextStyle(color: textFaint, fontSize: 14),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
    dividerColor: borderDark,
  );

  static ThemeData get light => ThemeData(
    useMaterial3: true, brightness: Brightness.light,
    scaffoldBackgroundColor: const Color(0xFFF4F6FB),
    colorScheme: const ColorScheme.light(
      primary: primaryDark, secondary: accent, error: error,
      surface: Colors.white, onPrimary: Colors.white),
    textTheme: GoogleFonts.interTextTheme(ThemeData.light().textTheme));
}

enum StopStatusX { pending, delivered, failed, absent, postponed }
