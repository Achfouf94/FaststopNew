import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'services/route_provider.dart';
import 'utils/app_theme.dart';
import 'screens/dashboard_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark));
  await initializeDateFormatting('fr_FR', null);
  runApp(MultiProvider(
    providers: [ChangeNotifierProvider(create: (_) => RouteProvider()..loadRoutes())],
    child: const FastStopApp(),
  ));
}

class FastStopApp extends StatelessWidget {
  const FastStopApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'FastStop',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.light,
    darkTheme: AppTheme.dark,
    themeMode: ThemeMode.dark,
    home: const SplashScreen(),
  );
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade, _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _fade = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.6, curve: Curves.easeOut)));
    _scale = Tween<double>(begin: 0.7, end: 1).animate(
        CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.6, curve: Curves.elasticOut)));
    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 2200), () {
      if (mounted) Navigator.pushReplacement(context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 400),
          pageBuilder: (_, __, ___) => const DashboardScreen(),
          transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
        ));
    });
  }

  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bgDark,
    body: Center(
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => FadeTransition(
          opacity: _fade,
          child: ScaleTransition(
            scale: _scale,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                width: 96, height: 96,
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: AppTheme.primary.withOpacity(0.3), width: 2)),
                child: const Icon(Icons.local_shipping_rounded, color: AppTheme.primary, size: 52)),
              const SizedBox(height: 24),
              RichText(text: const TextSpan(children: [
                TextSpan(text: 'Fast', style: TextStyle(color: AppTheme.textPrimary, fontSize: 36, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                TextSpan(text: 'Stop', style: TextStyle(color: AppTheme.primary, fontSize: 36, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
              ])),
              const SizedBox(height: 8),
              const Text('Optimise pour Bruxelles',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 14, letterSpacing: 0.3)),
            ]),
          ),
        ),
      ),
    ),
  );
}
