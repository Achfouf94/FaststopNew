# 🚀 Guide complet GitHub Actions — FastStop

## Workflows disponibles

| Fichier | Déclencheur | Runner | Résultat |
|---------|-------------|--------|----------|
| `build-ios.yml` | Push sur `main` | macOS (gratuit) | IPA non-signé |
| `build-android.yml` | Push sur `main` | Ubuntu (gratuit) | APK release |
| `build-all.yml` | Tag `v*.*.*` | macOS + Ubuntu | IPA + APK + GitHub Release |

---

## Étape 1 — Mettre le projet sur GitHub

```bash
# Dans ton dossier FastStop (après flutter create + copie des fichiers)
git init
git add .
git commit -m "feat: initial FastStop project"
git branch -M main

# Créer un repo sur github.com, puis :
git remote add origin https://github.com/TON_USERNAME/faststop.git
git push -u origin main
```

---

## Étape 2 — Les workflows se déclenchent automatiquement

1. Va sur **github.com/TON_USERNAME/faststop**
2. Clique sur **Actions** (onglet en haut)
3. Tu verras les workflows `Build iOS IPA` et `Build Android APK` en cours
4. ⏱ Durée estimée : iOS ~15-20 min, Android ~8-10 min

---

## Étape 3 — Télécharger l'IPA

1. Dans GitHub Actions → clique sur le workflow terminé ✅
2. En bas de page → section **Artifacts**
3. Clique **FastStop-iOS-IPA** → télécharge le `.zip`
4. Extrais → tu as ton `FastStop-unsigned.ipa` 🎉

---

## Étape 4 — Installer sur iPhone

### Option A : ESign (directement sur iPhone, sans PC) ⭐ RECOMMANDÉ
1. Ouvre ESign sur iPhone
2. **Importer le .ipa** depuis iCloud / AirDrop
3. **Importer ton certificat P12** (si tu n'en as pas, cherche "certificat iOS gratuit")
4. Appuie sur le .ipa → **Sign** → **Install**

### Option B : Sideloadly (Windows/Mac)
1. Télécharge Sideloadly sur [sideloadly.io](https://sideloadly.io)
2. Connecte l'iPhone en USB
3. Drag & drop `FastStop-unsigned.ipa`
4. Entre ton Apple ID → **Start** → Installe

### Option C : AltStore
1. AltStore installé → **My Apps** → `+`
2. Sélectionne `FastStop-unsigned.ipa`
3. Valide avec ton Apple ID (gratuit, valide 7 jours)

---

## Release automatique avec tag (optionnel)

```bash
# Créer une release v1.0.0 (build iOS + Android + GitHub Release automatique)
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0
```
→ GitHub crée automatiquement une Release avec l'IPA + APK en pièces jointes !

---

## Limites gratuites GitHub Actions

| Runner | Minutes gratuites/mois | Estimation FastStop |
|--------|----------------------|---------------------|
| Ubuntu | 2 000 min | ~200 builds Android |
| macOS  | 2 000 min | ~100 builds iOS |

Largement suffisant pour usage personnel ! 🟢
