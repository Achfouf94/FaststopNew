# 🚚 FastStop — Gestion de livraisons Bruxelles

Application Flutter personnelle pour chauffeurs livreurs.
Optimisee pour Bruxelles. 100% offline. Zero abonnement.

## Fonctionnalites
- Creation de routes avec stops (adresse, client, telephone, notes)
- Optimisation automatique : Nearest Neighbor + 2-opt (TSP)
- Geocodage gratuit via OpenStreetMap Nominatim (sans cle API)
- Navigation vers Apple Maps / Google Maps / Waze
- Swipe gauche = Livre / Swipe droite = Echec
- Drag & drop pour reordonner les stops
- Historique avec statistiques globales
- Persistance locale SQLite

## Build

### Dependances
```bash
flutter pub get
```

### iOS IPA (sans signature — pour AltStore/Sideloadly/ESign)
```bash
flutter build ios --release --no-codesign
mkdir -p Payload
cp -r build/ios/Release-iphoneos/Runner.app Payload/
zip -r FastStop.ipa Payload/
rm -rf Payload/
```

### Android APK
```bash
flutter build apk --release
# Fichier : build/app/outputs/flutter-apk/app-release.apk
```

## Installer l'IPA sur iPhone
- **ESign** (sans PC) : importer le .ipa + ton certificat P12 → signer → installer
- **Sideloadly** (PC/Mac) : drag & drop .ipa → entrer Apple ID → installer
- **AltStore** : My Apps → + → selectionner le .ipa

## Architecture
```
lib/
├── main.dart
├── models/        stop_model.dart, route_model.dart
├── services/      database_service.dart, route_optimizer.dart, geo_service.dart, route_provider.dart
├── screens/       dashboard, create_route, route_detail, active_route, history, settings
├── widgets/       stop_tile, route_card, stat_card
└── utils/         app_theme.dart
```
